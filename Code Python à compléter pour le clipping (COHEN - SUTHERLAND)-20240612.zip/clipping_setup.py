from turtle_setup import prep_graphe

IN, TOP, BOTTOM, LEFT, RIGHT = [0, 2, 1, 8, 4]
INSIDE, OUTSIDE, OVERLAP = [0, 1, 2]

class Point:

    def __init__(self, x, y):
        self.x, self.y = int(x), int(y)

    def __repr__(self):
        return '(' + str(self.x) + ', ' + str(self.y) + ')'

    def __str__(self):
        return '(' + str(self.x) + ', ' + str(self.y) + ')'

    def __eq__(self, other):
        return (self.x == other.x) and (self.y == other.y)

class Segment:

    def __init__(self, p1, p2, tri = None):
        self.pstart = p1
        self.pend = p2
        self.tag = None
        self.triangle = tri

    def __str__(self):
        return str(self.pstart)+'; '+str(self.pend)

    def __eq__(self, other):
        return (self.pstart == other.pstart) and (self.pend == other.pend)

class Triangle:

    def __init__(self, S1=Point(0, 0), S2=Point(0, 0), S3=Point(0, 0)):
        self.S1, self.S2, self.S3 = S1, S2, S3
        E1 = Segment(S1, S2, self)
        E2 = Segment(S2, S3, self)
        E3 = Segment(S3, S1, self)
        self.edges = [E1, E2, E3]

class Mesh:
    def __init__(self, tri_list):
        self.triangle_list = tri_list


class Clip_space:

    def __init__(self, mesh, upleft=Point(0, 0), bottomright=Point(640, 480)):
        self.mesh = mesh
        self.upleft = upleft
        self.bottomright = bottomright
        # limites du clop_space
        self.xmin = upleft.x
        self.xmax = bottomright.x
        self.ymin = upleft.y
        self.ymax = bottomright.y
        # liste de segments classés inside, outside, overlap (à cheval)
        self.inside = []
        self.outside = []
        self.overlap = []
    #
    # fonction à compléter
    #
    def position(self, p): #donne la position d'un point P par rapport au clip space
        pos = IN
        x, y = p.x, p.y

        # a vous de jouer

        return pos

    #
    #  fonction à compléter
    #
    def tag_segment(self, seg):
        codestart = self.position(seg.pstart)
        codeend = self.position(seg.pend)
        # on doit determiner si le segment est 'inside', 'outside' ou 'overlap'
        # puis le ranger dans la liste correspondante

        return

    def tag_triangles(self):
        for tri in self.mesh.triangle_list:
            for e in tri.edges:
                self.tag_segment(e)
        return

    #
    #  fonction à compléter
    #
    def clip_segment(self,seg):
        # on retire le segment de la liste des segments overlap
        if seg.tag == OVERLAP:
            self.overlap.remove(seg)

        # on récupère les points extrémités
        ps, pe = seg.pstart, seg.pend

        # et on calcule leur position (TOP ? LEFT ? IN)
        pos_s = self.position(ps)
        pos_e = self.position(pe)

        # nseg sera le segment modifié par le clipping
        nseg = seg

        # calcul de dx et dy pour la suite du traitement

        while pos_s != IN:    # tant que le point de départ est hors du clipping space
            # a vous de jouer
            pass

        while pos_e != IN:  # tant que le point de fin est hors du clipping space
            # à vous de jouer
            pass


        # on insère le nouveau segment (traité) dans une des listes
        self.tag_segment(nseg)

        return

    def clipall(self):
        while self.overlap != []:
            for seg in self.overlap:
                self.clip_segment(seg)
                prep_graphe(self)

        return
