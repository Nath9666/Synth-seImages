from clipping_setup import *
from turtle_setup import *
from time import sleep

points = [[320, 400], [480, 240], [200, 220], [340, 200], [300, -20], [460, 20], [500, -50], [700, -40], [750, 20],
          [720, 380], [680, 220]]

edges = [[1, 3, 4], [1, 2, 4], [3, 4, 5], [4, 5, 6], [2, 4, 6], [5, 6, 7], [6, 7, 8], [6, 8, 11], [2, 6, 11], [8, 9, 11], [9, 10, 11], [2, 10, 11]]


def tobin(value):
    return bin(value)[2:]


def make_triangles():
    global triangles
    triangles = []
    for e in edges:
        i1, i2, i3 = e
        p1, p2, p3 = points[i1-1], points[i2-1], points[i3-1]
        pt1 = Point(p1[0], p1[1])
        pt2 = Point(p2[0], p2[1])
        pt3 = Point(p3[0], p3[1])
        tri = Triangle(pt1, pt2, pt3)
        triangles += [tri]

    return Mesh(triangles)

mesh = make_triangles()
clip_space = cl.Clip_space(mesh)
clip_space.tag_triangles()
prep_graphe(clip_space)
clip_space.clipall()

sleep(5)