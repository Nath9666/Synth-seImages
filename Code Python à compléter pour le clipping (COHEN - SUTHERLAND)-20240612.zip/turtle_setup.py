from turtle import *
from time import sleep
import clipping_setup as cl

def prep_graphe(clip_space, w = 800, h = 600):
    delay(0)
    Screen().setup(w, h)
    # coeffs de changement de repere pour affichage
    # calcul des coefficients pour passer en coordonnes fenetre

    offset = 100

    xmax = clip_space.xmax
    xmin = clip_space.xmin
    ymax = clip_space.ymax
    ymin = clip_space.ymin

    a_x = w / (xmax - xmin + 2*offset)
    b_x = (w / 2) - (a_x * (xmax+offset))
    a_y = h / (ymax - ymin + 2*offset)
    b_y = (h / 2) - (a_y * (ymax+offset))
    clear()
    #dessin du clip space
    color('black')
    up()
    setposition(a_x * xmin + b_x, a_y * ymin+b_y)
    down()
    setposition(a_x * xmin + b_x, a_y*ymax+b_y)
    setposition(a_x * xmax + b_x, a_y*ymax+b_y)
    setposition(a_x * xmax + b_x, a_y* ymin +b_y)
    setposition(a_x * xmin + b_x, a_y* ymin +b_y)
    up()

    # dessin des arêtes

    color('red')
    for seg in clip_space.outside:
        xs, ys, xe, ye = seg.pstart.x, seg.pstart.y, seg.pend.x, seg.pend.y
        up()
        setposition(a_x*xs+b_x, a_y*ys+b_y)
        down()
        setposition(a_x*xe+b_x, a_y*ye+b_y)

    color('orange')
    for seg in clip_space.overlap:
        xs, ys, xe, ye = seg.pstart.x, seg.pstart.y, seg.pend.x, seg.pend.y
        up()
        setposition(a_x*xs+b_x, a_y*ys+b_y)
        down()
        setposition(a_x*xe+b_x, a_y*ye+b_y)

    color('green')
    for seg in clip_space.inside:
        xs, ys, xe, ye = seg.pstart.x, seg.pstart.y, seg.pend.x, seg.pend.y
        up()
        setposition(a_x*xs+b_x, a_y*ys+b_y)
        down()
        setposition(a_x*xe+b_x, a_y*ye+b_y)

    sleep(1)

    return