#ifndef KUBE_H_INCLUDED
#define KUBE_H_INCLUDED

#include "Ogre.h"

using namespace Ogre;

class Kube
{
    public :
	   static MeshPtr createKube(SceneManager *manager);
};

#endif // KUBE_H_INCLUDED
