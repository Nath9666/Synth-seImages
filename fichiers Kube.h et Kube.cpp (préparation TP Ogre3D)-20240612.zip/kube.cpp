#include "Kube.h"

#include <iostream>
#include <fstream>

using namespace std;

MeshPtr Terrain::createKube(SceneManager *manager)
{
	MeshPtr tmesh;
	tmesh.setNull();

	ManualObject *manual = manager->createManualObject("kube");

    manual->begin("kube");

	// pour positionner un sommet dans l'espace 3D
	// il faut en positionner 8
	/// x, y et z seront les coordonnées à préciser
    manual->position(x,y,z);

    // et un quad pour chacune des faces du kube
	manual->quad(?, ?, ?, ?);
	manual->quad(?, ?, ?, ?);
	manual->quad(?, ?, ?, ?);
	manual->quad(?, ?, ?, ?);
	manual->quad(?, ?, ?, ?);
	manual->quad(?, ?, ?, ?);


	manual->end();

    tmesh = manual->convertToMesh("kube", ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME);

    manager->destroyManualObject(manual);

    return tmesh;
}
